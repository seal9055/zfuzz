module Unicorn
  VERSION = "2.0.0"
end
